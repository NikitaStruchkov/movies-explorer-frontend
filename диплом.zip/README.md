# название макета: light-4

[Ссылка на макет в Figma](https://www.figma.com/file/jIbIgdrMonJBH2NAIq9g32/%D0%94%D0%B8%D0%BF%D0%BB%D0%BE%D0%BC%D0%BD%D1%8B%D0%B9-%D0%BF%D1%80%D0%BE%D0%B5%D0%BA%D1%82-(Copy)?type=design&node-id=1-2798&mode=design&t=IomxAf1MZ2TC92lk-0)
