import './promo.css'
import React from 'react'

export default function Promo () {
  return (
    <article className='promo'>
      <p className='promo__title'>
        Учебный проект студента факультета Веб-разработки.
      </p>
    </article>
  )
}
